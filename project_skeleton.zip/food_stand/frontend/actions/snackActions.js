/*
In this file we will define our Snack Actions!

Look at fruitActions as a reference if you get stuck.
// NOTE: Remember to export!
*/

// 1. Define action constant


// 2. Define addSnack action and clearSnacks
