import React from 'react';
import FruitStandContainer from './fruit_stand_container';
// 1. Import your SnackContainer component

const App = (props) => {
  return(
    <section>
      <FruitStandContainer />
      // 2. render your SnackContainer component here
    </section>
  );
};

export default App;
