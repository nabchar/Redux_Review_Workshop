export const ADD_HOTDOG = "ADD_HOTDOG";

export const addHotDog = () => {
  return {
    type: ADD_HOTDOG
  };
};
